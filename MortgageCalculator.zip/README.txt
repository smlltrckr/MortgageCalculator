Team 3:
Krystle Weinrich- new launcher icon/splash screen, create README, create screenshots, payment functions

Sam Rucker-creating activities and their corresponding xmls, date calculation, error checking

Sheethal Mathew- error checking, testing, theme changes

Ho Yeung Lai- theme changes, testing, formatting



The app launcher icon is under "Creative Commons Attribution-NoDerivs 3.0 Unported" license and can be found at: http://ic8.link/20027